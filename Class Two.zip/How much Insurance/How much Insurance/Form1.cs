namespace How_much_Insurance

{
    using System;
    using System.Globalization;
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            double cost;
            const double div = 0.8;
            double amount;

            cost = double.Parse(textBox1.Text);

            amount = cost * div;

            answer.Text = amount.ToString("C", CultureInfo.GetCultureInfo("en-GH"));
        }
    }
}
