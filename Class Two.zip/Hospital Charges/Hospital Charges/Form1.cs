using System.Security.Cryptography.X509Certificates;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Hospital_Charges
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public float stayCharges;
        public float medic, lab, rehab, surg, answ, ch;

        private void button1_Click(object sender, EventArgs e)
        {


            float.TryParse(txtMedic.Text, out medic);
            float.TryParse(txtLab.Text, out lab);
            float.TryParse(txtRehab.Text, out rehab);
            float.TryParse(txtSurg.Text, out surg);
            float.TryParse(txtDays.Text, out stayCharges);

            CalcTotalCharges();

        }

        private float CalcStayCharges(float stayCharges)
        {
            if (stayCharges > 0)
            {
                answ = stayCharges * 350;

            }
            else
            {
                MessageBox.Show("The day must not be less than 1", "Error");
            }

            return answ;
        }

        private float CalcMiscCharges(float medic, float lab, float rehab, float surg)
        {
            if (medic >= 0 && lab >= 0 && rehab >= 0 && surg >= 0)
            {
                ch = medic + lab + rehab + surg;
            }
            else
            {
                MessageBox.Show("Invalid Input", "Error");
            }
            return ch;
        }

        private void CalcTotalCharges()
        {
            


            float ans1 = CalcStayCharges(stayCharges);




            float ans2 = CalcMiscCharges(medic, lab, rehab, surg);




            float total = ans1 + ans2;

            lblMisc.Text = ans2.ToString();
            lblTotal.Text = total.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            txtDays.Text = "";
            txtLab.Text = "";
            txtMedic.Text = "";
            txtRehab.Text = "";
            txtSurg.Text = "";
            lblMisc.Text = "0.00";
            lblTotal.Text = "0.00";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
