﻿namespace Hospital_Charges
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            txtDays = new TextBox();
            txtMedic = new TextBox();
            txtSurg = new TextBox();
            txtLab = new TextBox();
            txtRehab = new TextBox();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            label6 = new Label();
            lblMisc = new Label();
            label8 = new Label();
            lblTotal = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(59, 38);
            label1.Name = "label1";
            label1.Size = new Size(186, 15);
            label1.TabIndex = 0;
            label1.Text = "Number of Days Spent in Hospital";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(59, 122);
            label2.Name = "label2";
            label2.Size = new Size(174, 15);
            label2.TabIndex = 1;
            label2.Text = "Amount of Medication Charges";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(59, 192);
            label3.Name = "label3";
            label3.Size = new Size(156, 15);
            label3.TabIndex = 2;
            label3.Text = "Amount of Surgical Charges";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(59, 286);
            label4.Name = "label4";
            label4.Size = new Size(108, 15);
            label4.TabIndex = 3;
            label4.Text = "Amount of lab fees";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(59, 351);
            label5.Name = "label5";
            label5.Size = new Size(147, 15);
            label5.TabIndex = 4;
            label5.Text = "Amount of Physical Rehab";
            // 
            // txtDays
            // 
            txtDays.Location = new Point(285, 38);
            txtDays.Name = "txtDays";
            txtDays.Size = new Size(164, 23);
            txtDays.TabIndex = 5;
            // 
            // txtMedic
            // 
            txtMedic.Location = new Point(285, 114);
            txtMedic.Name = "txtMedic";
            txtMedic.Size = new Size(164, 23);
            txtMedic.TabIndex = 6;
            // 
            // txtSurg
            // 
            txtSurg.Location = new Point(285, 184);
            txtSurg.Name = "txtSurg";
            txtSurg.Size = new Size(164, 23);
            txtSurg.TabIndex = 7;
            // 
            // txtLab
            // 
            txtLab.Location = new Point(285, 278);
            txtLab.Name = "txtLab";
            txtLab.Size = new Size(164, 23);
            txtLab.TabIndex = 8;
            // 
            // txtRehab
            // 
            txtRehab.Location = new Point(285, 343);
            txtRehab.Name = "txtRehab";
            txtRehab.Size = new Size(164, 23);
            txtRehab.TabIndex = 9;
            // 
            // button1
            // 
            button1.Location = new Point(650, 48);
            button1.Name = "button1";
            button1.Size = new Size(92, 33);
            button1.TabIndex = 10;
            button1.Text = "Calculate";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(650, 144);
            button2.Name = "button2";
            button2.Size = new Size(92, 33);
            button2.TabIndex = 11;
            button2.Text = "Clear";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.Location = new Point(650, 241);
            button3.Name = "button3";
            button3.Size = new Size(92, 33);
            button3.TabIndex = 12;
            button3.Text = "Exit";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(59, 423);
            label6.Name = "label6";
            label6.Size = new Size(128, 15);
            label6.TabIndex = 13;
            label6.Text = "Miscellaneous Charges";
            // 
            // lblMisc
            // 
            lblMisc.AutoSize = true;
            lblMisc.Location = new Point(89, 462);
            lblMisc.Name = "lblMisc";
            lblMisc.Size = new Size(53, 15);
            lblMisc.TabIndex = 14;
            lblMisc.Text = "GHC0.00";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(285, 423);
            label8.Name = "label8";
            label8.Size = new Size(78, 15);
            label8.TabIndex = 15;
            label8.Text = "Total Charges";
            // 
            // lblTotal
            // 
            lblTotal.AutoSize = true;
            lblTotal.Location = new Point(299, 462);
            lblTotal.Name = "lblTotal";
            lblTotal.Size = new Size(53, 15);
            lblTotal.TabIndex = 16;
            lblTotal.Text = "GHC0.00";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightGoldenrodYellow;
            ClientSize = new Size(800, 509);
            Controls.Add(lblTotal);
            Controls.Add(label8);
            Controls.Add(lblMisc);
            Controls.Add(label6);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(txtRehab);
            Controls.Add(txtLab);
            Controls.Add(txtSurg);
            Controls.Add(txtMedic);
            Controls.Add(txtDays);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Hospital Charges";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private TextBox txtDays;
        private TextBox txtMedic;
        private TextBox txtSurg;
        private TextBox txtLab;
        private TextBox txtRehab;
        private Button button1;
        private Button button2;
        private Button button3;
        private Label label6;
        private Label lblMisc;
        private Label label8;
        private Label lblTotal;
    }
}
