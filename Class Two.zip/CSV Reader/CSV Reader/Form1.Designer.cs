﻿namespace CSV_Reader
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            listBox1 = new ListBox();
            btnScores = new Button();
            btnExit = new Button();
            SuspendLayout();
            // 
            // listBox1
            // 
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 15;
            listBox1.Location = new Point(69, 19);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(188, 169);
            listBox1.TabIndex = 0;
            // 
            // btnScores
            // 
            btnScores.Location = new Point(77, 223);
            btnScores.Name = "btnScores";
            btnScores.Size = new Size(85, 42);
            btnScores.TabIndex = 1;
            btnScores.Text = "Get Scores";
            btnScores.UseVisualStyleBackColor = true;
            btnScores.Click += btnScores_Click;
            // 
            // btnExit
            // 
            btnExit.Location = new Point(182, 223);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(75, 42);
            btnExit.TabIndex = 2;
            btnExit.Text = "Exit";
            btnExit.UseVisualStyleBackColor = true;
            btnExit.Click += button1_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(310, 303);
            Controls.Add(btnExit);
            Controls.Add(btnScores);
            Controls.Add(listBox1);
            Name = "Form1";
            Text = "CSV Reader";
            ResumeLayout(false);
        }

        #endregion

        private ListBox listBox1;
        private Button btnScores;
        private Button btnExit;
    }
}
