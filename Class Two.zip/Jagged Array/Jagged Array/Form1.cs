using System;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace Jagged_Array
{
    public partial class Form1 : Form
    {
        private int[][] scores; // Jagged array for scores

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Load scores from files into a jagged array
            scores = new int[3][];
            scores[0] = LoadScoresFromFile("Section1.txt");
            scores[1] = LoadScoresFromFile("Section2.txt");
            scores[2] = LoadScoresFromFile("Section3.txt");

            // Display scores in ListBoxes
            DisplayScores(listBox1, scores[0]);
            DisplayScores(listBox2, scores[1]);
            DisplayScores(listBox3, scores[2]);

            // Calculate and display statistics
            CalculateStatistics();
        }

        private int[] LoadScoresFromFile(string fileName)
        {
            try
            {
                return File.ReadAllLines(fileName).Select(int.Parse).ToArray();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error reading {fileName}: {ex.Message}");
                return new int[0]; // Return empty array if error occurs
            }
        }

        private void DisplayScores(ListBox listBox, int[] sectionScores)
        {
            listBox.Items.Clear();
            foreach (var score in sectionScores)
            {
                listBox.Items.Add(score);
            }
        }

        private void CalculateStatistics()
        {
            if (scores == null || scores.Any(s => s.Length == 0)) return;

            double avg1 = scores[0].Average();
            double avg2 = scores[1].Average();
            double avg3 = scores[2].Average();
            double overallAvg = scores.SelectMany(s => s).Average();

            int highestScore = scores.SelectMany(s => s).Max();
            int lowestScore = scores.SelectMany(s => s).Min();
            int highSection = FindSection(highestScore);
            int lowSection = FindSection(lowestScore);

            label1.Text = $"Section 1 Avg: {avg1:F2}";
            label2.Text = $"Section 2 Avg: {avg2:F2}";
            label3.Text = $"Section 3 Avg: {avg3:F2}";
            label4.Text = $"Overall Avg: {overallAvg:F2}";
            label5.Text = $"Highest: {highestScore} (Section {highSection})";
            label6.Text = $"Lowest: {lowestScore} (Section {lowSection})";
        }

        private int FindSection(int score)
        {
            for (int i = 0; i < scores.Length; i++)
            {
                if (scores[i].Contains(score)) return i + 1;
            }
            return -1; // Not found
        }

        private void button2_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            listBox2.Items.Clear();
            listBox3.Items.Clear();
            label1.Text = "";
            label2.Text = "";
            label3.Text = "";
            label4.Text = "";
            label5.Text = "";
            label6.Text = "";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}