﻿namespace LatinTranslator
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            translate = new Label();
            btnLatin = new Button();
            button1 = new Button();
            button2 = new Button();
            SuspendLayout();
            // 
            // translate
            // 
            translate.AutoSize = true;
            translate.BackColor = Color.FromArgb(255, 255, 128);
            translate.BorderStyle = BorderStyle.FixedSingle;
            translate.Font = new Font("Microsoft YaHei UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            translate.Location = new Point(232, 113);
            translate.Name = "translate";
            translate.Size = new Size(2, 28);
            translate.TabIndex = 0;
            translate.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // btnLatin
            // 
            btnLatin.BackColor = Color.Yellow;
            btnLatin.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnLatin.Location = new Point(220, 188);
            btnLatin.Name = "btnLatin";
            btnLatin.Size = new Size(81, 38);
            btnLatin.TabIndex = 1;
            btnLatin.Text = "sinister";
            btnLatin.UseVisualStyleBackColor = false;
            btnLatin.Click += button1_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.Yellow;
            button1.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.Location = new Point(341, 188);
            button1.Name = "button1";
            button1.Size = new Size(81, 38);
            button1.TabIndex = 2;
            button1.Text = "dexter";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click_1;
            // 
            // button2
            // 
            button2.BackColor = Color.Yellow;
            button2.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.Location = new Point(468, 188);
            button2.Name = "button2";
            button2.Size = new Size(81, 38);
            button2.TabIndex = 3;
            button2.Text = "medium";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(192, 64, 0);
            ClientSize = new Size(800, 450);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(btnLatin);
            Controls.Add(translate);
            Name = "Form1";
            Text = "Latin Translator";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label translate;
        private Button btnLatin;
        private Button button1;
        private Button button2;
    }
}
