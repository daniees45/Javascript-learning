﻿namespace Distance_Calculator
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            txtSpeed = new TextBox();
            txtHours = new TextBox();
            listDist = new ListBox();
            btnCalculate = new Button();
            btnExit = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(89, 30);
            label1.Name = "label1";
            label1.Size = new Size(164, 21);
            label1.TabIndex = 5;
            label1.Text = "Vehicle Speed in MPH:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(89, 90);
            label2.Name = "label2";
            label2.Size = new Size(121, 21);
            label2.TabIndex = 6;
            label2.Text = "Hours Traveled: ";
            // 
            // txtSpeed
            // 
            txtSpeed.Location = new Point(277, 29);
            txtSpeed.Name = "txtSpeed";
            txtSpeed.Size = new Size(155, 23);
            txtSpeed.TabIndex = 0;
            // 
            // txtHours
            // 
            txtHours.Location = new Point(277, 92);
            txtHours.Name = "txtHours";
            txtHours.Size = new Size(155, 23);
            txtHours.TabIndex = 1;
            // 
            // listDist
            // 
            listDist.FormattingEnabled = true;
            listDist.ItemHeight = 15;
            listDist.Location = new Point(89, 139);
            listDist.Name = "listDist";
            listDist.Size = new Size(343, 184);
            listDist.TabIndex = 2;
            // 
            // btnCalculate
            // 
            btnCalculate.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnCalculate.Location = new Point(125, 366);
            btnCalculate.Name = "btnCalculate";
            btnCalculate.Size = new Size(111, 31);
            btnCalculate.TabIndex = 3;
            btnCalculate.Text = "&Calculate";
            btnCalculate.UseVisualStyleBackColor = true;
            btnCalculate.Click += btnCalculate_Click;
            // 
            // btnExit
            // 
            btnExit.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnExit.Location = new Point(267, 366);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(111, 31);
            btnExit.TabIndex = 4;
            btnExit.Text = "&Exit";
            btnExit.UseVisualStyleBackColor = true;
            btnExit.Click += btnExit_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(560, 450);
            Controls.Add(btnExit);
            Controls.Add(btnCalculate);
            Controls.Add(listDist);
            Controls.Add(txtHours);
            Controls.Add(txtSpeed);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Distance Calculator Application";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox txtSpeed;
        private TextBox txtHours;
        private ListBox listDist;
        private Button btnCalculate;
        private Button btnExit;
    }
}
