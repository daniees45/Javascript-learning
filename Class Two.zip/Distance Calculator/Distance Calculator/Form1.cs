namespace Distance_Calculator
    
{
    using System.IO;
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            double speed = double.Parse(txtSpeed.Text);
            int time = int.Parse(txtHours.Text);
            double distance;
            int i = 1;
            StreamWriter obj = new StreamWriter("Distance.txt");
            

            do
            {
                distance = speed * i;
               
                listDist.Items.Add("After hours " + i.ToString() + ", the distance is " + distance.ToString());
                obj.Write("After hours " + i.ToString() + ", the distance is " + distance.ToString() +"\n");
                i++;
            }
            while (i <= time);
            obj.Close();
            //for (int i = 1; i <= time; i++)
            //{
            //    distance = speed * i;
            //    listDist.Items.Add("After hours " + i.ToString() + ", the distance is " + distance.ToString()
            //    );
            //}
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
