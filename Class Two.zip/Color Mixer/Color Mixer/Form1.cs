namespace Color_Mixer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            if (rdRed1.Checked && rdBlue2.Checked || rdBlue1.Checked && rdRed2.Checked)
            {
                this.BackColor = Color.Purple;
            }
            else if (rdRed1.Checked && rdYellow2.Checked || rdYellow1.Checked && rdRed2.Checked)
            {
                this.BackColor = Color.Orange;
            }
            else if (rdYellow1.Checked && rdBlue2.Checked || rdBlue1.Checked && rdYellow2.Checked)
            {
                this.BackColor = Color.Green;
            }
            else if (rdRed1.Checked && rdRed2.Checked)
            {
                this.BackColor = Color.Red;
            }
            else if (rdBlue2.Checked && rdBlue1.Checked)
            {
                this.BackColor = Color.Blue;
            }
            else if (rdYellow2.Checked && rdYellow1.Checked)
            {
                this.BackColor = Color.Yellow;
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.White;
            rdRed2.Checked = false;
            rdYellow2.Checked = false;
            rdBlue2.Checked = false;
            rdYellow1.Checked = false;
            rdBlue1.Checked = false;
            rdYellow2.Checked = false;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
