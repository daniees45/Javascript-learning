﻿namespace Color_Mixer
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            rdYellow1 = new RadioButton();
            rdBlue1 = new RadioButton();
            rdRed1 = new RadioButton();
            groupBox2 = new GroupBox();
            rdYellow2 = new RadioButton();
            rdBlue2 = new RadioButton();
            rdRed2 = new RadioButton();
            btnCalculate = new Button();
            btnClear = new Button();
            btnExit = new Button();
            label1 = new Label();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(rdYellow1);
            groupBox1.Controls.Add(rdBlue1);
            groupBox1.Controls.Add(rdRed1);
            groupBox1.Location = new Point(75, 89);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(234, 165);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Select First Color";
            // 
            // rdYellow1
            // 
            rdYellow1.AutoSize = true;
            rdYellow1.Location = new Point(54, 131);
            rdYellow1.Name = "rdYellow1";
            rdYellow1.Size = new Size(59, 19);
            rdYellow1.TabIndex = 2;
            rdYellow1.TabStop = true;
            rdYellow1.Text = "Yellow";
            rdYellow1.UseVisualStyleBackColor = true;
            // 
            // rdBlue1
            // 
            rdBlue1.AutoSize = true;
            rdBlue1.Location = new Point(54, 81);
            rdBlue1.Name = "rdBlue1";
            rdBlue1.Size = new Size(48, 19);
            rdBlue1.TabIndex = 1;
            rdBlue1.TabStop = true;
            rdBlue1.Text = "Blue";
            rdBlue1.UseVisualStyleBackColor = true;
            // 
            // rdRed1
            // 
            rdRed1.AutoSize = true;
            rdRed1.Location = new Point(54, 35);
            rdRed1.Name = "rdRed1";
            rdRed1.Size = new Size(45, 19);
            rdRed1.TabIndex = 0;
            rdRed1.TabStop = true;
            rdRed1.Text = "Red";
            rdRed1.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(rdYellow2);
            groupBox2.Controls.Add(rdBlue2);
            groupBox2.Controls.Add(rdRed2);
            groupBox2.Location = new Point(431, 89);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(234, 173);
            groupBox2.TabIndex = 1;
            groupBox2.TabStop = false;
            groupBox2.Text = "Select Second Color";
            // 
            // rdYellow2
            // 
            rdYellow2.AutoSize = true;
            rdYellow2.Location = new Point(42, 131);
            rdYellow2.Name = "rdYellow2";
            rdYellow2.Size = new Size(59, 19);
            rdYellow2.TabIndex = 5;
            rdYellow2.TabStop = true;
            rdYellow2.Text = "Yellow";
            rdYellow2.UseVisualStyleBackColor = true;
            // 
            // rdBlue2
            // 
            rdBlue2.AutoSize = true;
            rdBlue2.Location = new Point(42, 81);
            rdBlue2.Name = "rdBlue2";
            rdBlue2.Size = new Size(48, 19);
            rdBlue2.TabIndex = 4;
            rdBlue2.TabStop = true;
            rdBlue2.Text = "Blue";
            rdBlue2.UseVisualStyleBackColor = true;
            // 
            // rdRed2
            // 
            rdRed2.AutoSize = true;
            rdRed2.Location = new Point(42, 35);
            rdRed2.Name = "rdRed2";
            rdRed2.Size = new Size(45, 19);
            rdRed2.TabIndex = 3;
            rdRed2.TabStop = true;
            rdRed2.Text = "Red";
            rdRed2.UseVisualStyleBackColor = true;
            // 
            // btnCalculate
            // 
            btnCalculate.Location = new Point(131, 283);
            btnCalculate.Name = "btnCalculate";
            btnCalculate.Size = new Size(65, 34);
            btnCalculate.TabIndex = 2;
            btnCalculate.Text = "Calculate";
            btnCalculate.UseVisualStyleBackColor = true;
            btnCalculate.Click += btnCalculate_Click;
            // 
            // btnClear
            // 
            btnClear.Location = new Point(327, 283);
            btnClear.Name = "btnClear";
            btnClear.Size = new Size(65, 34);
            btnClear.TabIndex = 3;
            btnClear.Text = "Clear";
            btnClear.UseVisualStyleBackColor = true;
            btnClear.Click += btnClear_Click;
            // 
            // btnExit
            // 
            btnExit.Location = new Point(495, 283);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(65, 34);
            btnExit.TabIndex = 4;
            btnExit.Text = "Exit";
            btnExit.UseVisualStyleBackColor = true;
            btnExit.Click += btnExit_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(358, 171);
            label1.Name = "label1";
            label1.Size = new Size(38, 15);
            label1.TabIndex = 5;
            label1.Text = "label1";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label1);
            Controls.Add(btnExit);
            Controls.Add(btnClear);
            Controls.Add(btnCalculate);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Name = "Form1";
            Text = "Color Mixer";
            Load += Form1_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox groupBox1;
        private RadioButton rdYellow1;
        private RadioButton rdBlue1;
        private RadioButton rdRed1;
        private GroupBox groupBox2;
        private RadioButton rdYellow2;
        private RadioButton rdBlue2;
        private RadioButton rdRed2;
        private Button btnCalculate;
        private Button btnClear;
        private Button btnExit;
        private Label label1;
    }
}
