﻿namespace Heads_Or_Tails
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            btnHeads = new Button();
            btnTails = new Button();
            btnExit = new Button();
            pictureBox1 = new PictureBox();
            pictureBox2 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // btnHeads
            // 
            btnHeads.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            btnHeads.Location = new Point(156, 328);
            btnHeads.Name = "btnHeads";
            btnHeads.Size = new Size(89, 44);
            btnHeads.TabIndex = 0;
            btnHeads.Text = "Heads";
            btnHeads.UseVisualStyleBackColor = true;
            btnHeads.Click += btnHeads_Click;
            // 
            // btnTails
            // 
            btnTails.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            btnTails.Location = new Point(311, 328);
            btnTails.Name = "btnTails";
            btnTails.Size = new Size(89, 44);
            btnTails.TabIndex = 1;
            btnTails.Text = "Tails";
            btnTails.UseVisualStyleBackColor = true;
            btnTails.Click += btnTails_Click;
            // 
            // btnExit
            // 
            btnExit.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            btnExit.Location = new Point(456, 328);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(89, 44);
            btnExit.TabIndex = 2;
            btnExit.Text = "Exit";
            btnExit.UseVisualStyleBackColor = true;
            btnExit.Click += btnExit_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(88, 34);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(198, 221);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 3;
            pictureBox1.TabStop = false;
            pictureBox1.Visible = false;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(429, 40);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(208, 224);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 4;
            pictureBox2.TabStop = false;
            pictureBox2.Visible = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(pictureBox2);
            Controls.Add(pictureBox1);
            Controls.Add(btnExit);
            Controls.Add(btnTails);
            Controls.Add(btnHeads);
            Name = "Form1";
            Text = "Heads or Tails";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Button btnHeads;
        private Button btnTails;
        private Button btnExit;
        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
    }
}
