namespace Class_Two
{
    using System;
    using System.Globalization;
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public decimal genCharge = 1800;
        public decimal labFee = 150;
        public decimal clinicals = 560;
        public decimal creditRate = 120;

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnCalcuate_Click(object sender, EventArgs e)
        {

            //Input from Users
            decimal fees;
            int credits;

            int.TryParse(txtHours.Text, out credits);

            if(credits > 0 && credits <= 24)
            {
                //statment
                if (radioRegular.Checked && radioLocal.Checked)
                {
                    if (listDepartment.Items.Equals("Computer Science"))
                    {
                        fees = genCharge + labFee + (creditRate * credits);
                        totalFees.Text = fees.ToString("C", CultureInfo.GetCultureInfo("en-GH"));
                    }else if (listDepartment.Items.Equals("Nursing & Midwifery"))
                    {
                        fees = genCharge + clinicals + (creditRate * credits);
                        totalFees.Text = fees.ToString("C", CultureInfo.GetCultureInfo("en-GH"));
                    }else if (listDepartment.Items.Equals("Business Administration"))
                    {
                        fees = genCharge + (creditRate * credits);
                        totalFees.Text = fees.ToString("C", CultureInfo.GetCultureInfo("en-GH"));
                    }else if (listDepartment.Items.Equals("Theology"))
                    {
                        fees = genCharge + (creditRate * credits) - 500;
                        totalFees.Text = fees.ToString("C", CultureInfo.GetCultureInfo("en-GH"));
                    }else if (listDepartment.Items.Equals("Education"))
                    {
                        fees = genCharge + (creditRate * credits);
                        totalFees.Text = fees.ToString("C", CultureInfo.GetCultureInfo("en-GH"));
                    }else if (listDepartment.Items.Equals("Development Studies"))
                    {
                        fees = genCharge + (creditRate * credits) - 500;
                        totalFees.Text = fees.ToString("C", CultureInfo.GetCultureInfo("en-GH"));
                    }
                }
            }
            else
            {
                MessageBox.Show("Invalid Credit hours.", "Input Error");
            }


        }
    }
}
