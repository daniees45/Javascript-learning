﻿namespace Class_Two
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            txtHours = new TextBox();
            radioProject = new RadioButton();
            radioNormal = new RadioButton();
            listDepartment = new ListBox();
            groupBox1 = new GroupBox();
            groupBox2 = new GroupBox();
            radioDistance = new RadioButton();
            radioSandwich = new RadioButton();
            radioRegular = new RadioButton();
            groupBox3 = new GroupBox();
            radioForeign = new RadioButton();
            radioLocal = new RadioButton();
            btnCalcuate = new Button();
            btnReset = new Button();
            btnExit = new Button();
            label3 = new Label();
            totalFees = new Label();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            groupBox3.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Symbol", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(64, 25);
            label1.Name = "label1";
            label1.Size = new Size(104, 20);
            label1.TabIndex = 0;
            label1.Text = "Credit Hours";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Symbol", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(372, 25);
            label2.Name = "label2";
            label2.Size = new Size(99, 20);
            label2.TabIndex = 3;
            label2.Text = "Department";
            // 
            // txtHours
            // 
            txtHours.Location = new Point(66, 61);
            txtHours.Name = "txtHours";
            txtHours.Size = new Size(135, 23);
            txtHours.TabIndex = 0;
            // 
            // radioProject
            // 
            radioProject.AutoSize = true;
            radioProject.Location = new Point(30, 31);
            radioProject.Name = "radioProject";
            radioProject.Size = new Size(94, 29);
            radioProject.TabIndex = 0;
            radioProject.TabStop = true;
            radioProject.Text = "Project ";
            radioProject.UseVisualStyleBackColor = true;
            // 
            // radioNormal
            // 
            radioNormal.AutoSize = true;
            radioNormal.Location = new Point(29, 74);
            radioNormal.Name = "radioNormal";
            radioNormal.Size = new Size(93, 29);
            radioNormal.TabIndex = 1;
            radioNormal.TabStop = true;
            radioNormal.Text = "Normal";
            radioNormal.UseVisualStyleBackColor = true;
            radioNormal.CheckedChanged += radioButton2_CheckedChanged;
            // 
            // listDepartment
            // 
            listDepartment.BackColor = SystemColors.MenuHighlight;
            listDepartment.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            listDepartment.FormattingEnabled = true;
            listDepartment.ItemHeight = 21;
            listDepartment.Items.AddRange(new object[] { "Please Select Department", "Computer Science", "Nursing & Midwifery", "Business Adminsitration", "Theology", "Development Studies", "Education" });
            listDepartment.Location = new Point(372, 57);
            listDepartment.Name = "listDepartment";
            listDepartment.Size = new Size(216, 193);
            listDepartment.TabIndex = 4;
            // 
            // groupBox1
            // 
            groupBox1.BackColor = Color.Yellow;
            groupBox1.Controls.Add(radioNormal);
            groupBox1.Controls.Add(radioProject);
            groupBox1.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            groupBox1.Location = new Point(56, 137);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(185, 122);
            groupBox1.TabIndex = 1;
            groupBox1.TabStop = false;
            groupBox1.Text = "Course Type";
            // 
            // groupBox2
            // 
            groupBox2.BackColor = Color.Blue;
            groupBox2.Controls.Add(radioDistance);
            groupBox2.Controls.Add(radioSandwich);
            groupBox2.Controls.Add(radioRegular);
            groupBox2.Font = new Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            groupBox2.Location = new Point(56, 293);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(176, 184);
            groupBox2.TabIndex = 2;
            groupBox2.TabStop = false;
            groupBox2.Text = "Mode";
            // 
            // radioDistance
            // 
            radioDistance.AutoSize = true;
            radioDistance.Location = new Point(17, 128);
            radioDistance.Name = "radioDistance";
            radioDistance.Size = new Size(104, 29);
            radioDistance.TabIndex = 2;
            radioDistance.TabStop = true;
            radioDistance.Text = "Distance";
            radioDistance.UseVisualStyleBackColor = true;
            // 
            // radioSandwich
            // 
            radioSandwich.AutoSize = true;
            radioSandwich.Location = new Point(17, 78);
            radioSandwich.Name = "radioSandwich";
            radioSandwich.Size = new Size(111, 29);
            radioSandwich.TabIndex = 1;
            radioSandwich.TabStop = true;
            radioSandwich.Text = "Sandwich";
            radioSandwich.UseVisualStyleBackColor = true;
            // 
            // radioRegular
            // 
            radioRegular.AutoSize = true;
            radioRegular.BackColor = Color.Blue;
            radioRegular.Location = new Point(17, 30);
            radioRegular.Name = "radioRegular";
            radioRegular.Size = new Size(95, 29);
            radioRegular.TabIndex = 0;
            radioRegular.TabStop = true;
            radioRegular.Text = "Regular";
            radioRegular.UseVisualStyleBackColor = false;
            // 
            // groupBox3
            // 
            groupBox3.BackColor = Color.FromArgb(255, 128, 0);
            groupBox3.Controls.Add(radioForeign);
            groupBox3.Controls.Add(radioLocal);
            groupBox3.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            groupBox3.Location = new Point(372, 293);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(216, 184);
            groupBox3.TabIndex = 5;
            groupBox3.TabStop = false;
            groupBox3.Text = "Nationality";
            // 
            // radioForeign
            // 
            radioForeign.AutoSize = true;
            radioForeign.Location = new Point(22, 79);
            radioForeign.Name = "radioForeign";
            radioForeign.Size = new Size(121, 25);
            radioForeign.TabIndex = 1;
            radioForeign.TabStop = true;
            radioForeign.Text = "International";
            radioForeign.UseVisualStyleBackColor = true;
            // 
            // radioLocal
            // 
            radioLocal.AutoSize = true;
            radioLocal.Location = new Point(22, 32);
            radioLocal.Name = "radioLocal";
            radioLocal.Size = new Size(66, 25);
            radioLocal.TabIndex = 0;
            radioLocal.TabStop = true;
            radioLocal.Text = "Local";
            radioLocal.UseVisualStyleBackColor = true;
            // 
            // btnCalcuate
            // 
            btnCalcuate.BackColor = Color.Fuchsia;
            btnCalcuate.Location = new Point(710, 293);
            btnCalcuate.Name = "btnCalcuate";
            btnCalcuate.Size = new Size(102, 36);
            btnCalcuate.TabIndex = 6;
            btnCalcuate.Text = "Calculate Fees";
            btnCalcuate.UseVisualStyleBackColor = false;
            btnCalcuate.Click += btnCalcuate_Click;
            // 
            // btnReset
            // 
            btnReset.BackColor = Color.FromArgb(255, 255, 128);
            btnReset.Location = new Point(710, 346);
            btnReset.Name = "btnReset";
            btnReset.Size = new Size(89, 36);
            btnReset.TabIndex = 7;
            btnReset.Text = "Reset";
            btnReset.UseVisualStyleBackColor = false;
            // 
            // btnExit
            // 
            btnExit.BackColor = Color.Red;
            btnExit.Location = new Point(710, 414);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(89, 36);
            btnExit.TabIndex = 8;
            btnExit.Text = "Exit";
            btnExit.UseVisualStyleBackColor = false;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(671, 57);
            label3.Name = "label3";
            label3.Size = new Size(173, 21);
            label3.TabIndex = 9;
            label3.Text = "TOTAL SEMESTER FEES";
            label3.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // totalFees
            // 
            totalFees.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            totalFees.Location = new Point(718, 100);
            totalFees.Name = "totalFees";
            totalFees.Size = new Size(94, 35);
            totalFees.TabIndex = 10;
            totalFees.Text = "GHC0.00";
            totalFees.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(128, 255, 128);
            ClientSize = new Size(856, 529);
            Controls.Add(totalFees);
            Controls.Add(label3);
            Controls.Add(btnExit);
            Controls.Add(btnReset);
            Controls.Add(btnCalcuate);
            Controls.Add(groupBox3);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Controls.Add(listDepartment);
            Controls.Add(txtHours);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Valley View University Fee Calculator";
            Load += Form1_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox txtHours;
        private RadioButton radioProject;
        private RadioButton radioNormal;
        private ListBox listDepartment;
        private GroupBox groupBox1;
        private GroupBox groupBox2;
        private RadioButton radioDistance;
        private RadioButton radioSandwich;
        private RadioButton radioRegular;
        private GroupBox groupBox3;
        private RadioButton radioForeign;
        private RadioButton radioLocal;
        private Button btnCalcuate;
        private Button btnReset;
        private Button btnExit;
        private Label label3;
        private Label totalFees;
    }
}
