﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace ExternalDatabase
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            string str = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\\Users\\isaac\\source\\repos\\ExternalDatabase\\ExternalDatabase\\Login.accdb";
            System.Data.OleDb.OleDbConnection con = new OleDbConnection(str);


            try
            {
                con.Open();
                OleDbCommand oleDbCommand = new OleDbCommand("SELECT COUNT(*) FROM UserLogin WHERE USERID ='" + txtUser.Text + "'"+ "AND PASSWORD = '" + txtPassword.Text + "'", con);
                Object result = oleDbCommand.ExecuteScalar();
                int i;
                if (result != null && int.TryParse(result.ToString(), out i))
                {
                    if (i == 1)
                    {
                        MessageBox.Show("Entry Successful");
                        MessageBox.Show("i " + i);
                    }
                    else
                    {
                        MessageBox.Show("Error: Your Username or password is incorrect");
                    }
                }
                else
                {
                    MessageBox.Show("Invalid Database Response");
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            con.Close();
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
