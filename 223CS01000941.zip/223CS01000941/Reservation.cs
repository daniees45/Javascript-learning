﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _223CS01000941
{
    public partial class Reservation : Form
    {
        public Reservation()
        {
            InitializeComponent();
        }

        private void Reservation_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'hostelsDataSet.Hostel' table. You can move, or remove it, as needed.
            this.hostelTableAdapter.Fill(this.hostelsDataSet.Hostel);

        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            String hostel = lstHostel.SelectedItem.ToString();
            String roomType = lstRoom.SelectedItem.ToString();
            decimal totalCharge;
            
            decimal chargePerRoom;
            int duration;
            int.TryParse(txtDuration.Text, out duration);

            if (!int.TryParse(txtDuration.Text, out duration) || duration <= 0)
            {
                MessageBox.Show("Kindly enter a valid duration (greater than 0).");
                return;
            }








            if (hostel == "E.G White")
            {
                switch (roomType)
                {
                    case "1 in a Room":
                        chargePerRoom = 100;
                        break;
                    case "2 in a Room":
                        chargePerRoom = 70;
                        break;
                    case "4 in a Room":
                        chargePerRoom = 40;
                        break;
                    default:
                        MessageBox.Show("Kindly select a valid room type.");
                        return;
                }
                totalCharge = chargePerRoom * duration;
                txtTotal.Text = $"Total Charge: {totalCharge:C}";
            }
            


            if (hostel == "NAGSDA")
            {
                switch (roomType)
                {
                    case "1 in a Room":
                        chargePerRoom = 50;
                        break;
                    case "2 in a Room":
                        chargePerRoom = 30;
                        break;
                    case "4 in a Room":
                        chargePerRoom = 20;
                        break;
                    default:
                        MessageBox.Show("Please select a valid room type.");
                        return;
                }
                totalCharge = chargePerRoom * duration;
                txtTotal.Text = $"Total Charge: {totalCharge:C}";
            }


            if (hostel == "Bediako")
            {
                switch (roomType)
                {
                    case "1 in a Room":
                        chargePerRoom = 50;
                        break;
                    case "2 in a Room":
                        chargePerRoom = 30;
                        break;
                    case "4 in a Room":
                        chargePerRoom = 20;
                        break;
                    default:
                        MessageBox.Show("Please select a valid room type.");
                        return;
                }
                totalCharge = chargePerRoom * duration;
                txtTotal.Text = $"Total Charge: {totalCharge:C}";
            }


            if (hostel == "J.J Nortey")
            {
                switch (roomType)
                {
                    case "1 in a Room":
                        chargePerRoom = 100;
                        break;
                    case "2 in a Room":
                        chargePerRoom = 70;
                        break;
                    case "4 in a Room":
                        chargePerRoom = 40;
                        break;
                    default:
                        MessageBox.Show("Please select a valid room type.");
                        return;
                }
                totalCharge = chargePerRoom * duration;
                txtTotal.Text = $"Total Charge: {totalCharge:C}";
            }
          


        }
    }

           
}
