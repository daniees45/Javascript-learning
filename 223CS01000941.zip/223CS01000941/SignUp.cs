﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Contracts;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _223CS01000941
{
    public partial class SignUp : Form
    {
        private String ID, contact, password, name, Program;
        public SignUp()
        {
            InitializeComponent();
        }

        private void btnReserve_Click(object sender, EventArgs e)
        {
            Reservation res = new Reservation();
            res.ShowDialog();
        }

        private void btnSign_Click(object sender, EventArgs e)
        {
             name = txtName.Text.ToString();
            ID =txtId.Text.ToString();
            Program = txtProgram.Text.ToString();
             password = txtPassword.Text.ToString();
            contact= txtContact.Text.ToString();

            signIn(ID,name,Program, password, contact);

            Login log = new Login();
            log.ShowDialog();
        }

        public void signIn(String ID, String Name, String Program, String password, String Contact)
        {
            this.ID = ID;
            this.contact = Contact;
            this.name = Name;
            this.password = password;
            this.Program = Program;

        }

        public void setId()
        {
            this.ID = ID;
        }

        public void setPass()
        {
            this.password = password;
        }


        public String getId(String ID)
        {
            return ID;
        }

        public String getName(String Name)
        {
            return Name;
        }

        public String getProgram(String Program)
        {
            return Program;
        }

        public String getPassword(String password)
        {
            return password;
        }

        
        private void SignUp_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'registrationDataSet.SignUp' table. You can move, or remove it, as needed.
            this.signUpTableAdapter.Fill(this.registrationDataSet.SignUp);

        }

        private void studentIdLabel_Click(object sender, EventArgs e)
        {

        }
    }
}
