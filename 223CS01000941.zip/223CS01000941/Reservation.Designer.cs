﻿namespace _223CS01000941
{
    partial class Reservation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtRoom = new System.Windows.Forms.TextBox();
            this.txtDuration = new System.Windows.Forms.TextBox();
            this.lstHostel = new System.Windows.Forms.ListBox();
            this.hostelBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.hostelsDataSet = new _223CS01000941.HostelsDataSet();
            this.lstRoom = new System.Windows.Forms.ListBox();
            this.txtTotal = new System.Windows.Forms.Label();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.hostelTableAdapter = new _223CS01000941.HostelsDataSetTableAdapters.HostelTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.hostelBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hostelsDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(196, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(309, 56);
            this.label1.TabIndex = 0;
            this.label1.Text = "Make Room Reservation";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(49, 120);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(176, 24);
            this.label2.TabIndex = 1;
            this.label2.Text = "Select Hostel Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(49, 189);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(166, 24);
            this.label3.TabIndex = 2;
            this.label3.Text = "Select Room Type";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(49, 252);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(211, 24);
            this.label4.TabIndex = 3;
            this.label4.Text = "Enter number of Rooms";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(49, 311);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(139, 24);
            this.label5.TabIndex = 4;
            this.label5.Text = "Enter Durations";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(49, 364);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(118, 24);
            this.label6.TabIndex = 5;
            this.label6.Text = "Total Charge";
            // 
            // txtRoom
            // 
            this.txtRoom.AllowDrop = true;
            this.txtRoom.Location = new System.Drawing.Point(453, 257);
            this.txtRoom.MaxLength = 1;
            this.txtRoom.Name = "txtRoom";
            this.txtRoom.Size = new System.Drawing.Size(177, 20);
            this.txtRoom.TabIndex = 8;
            // 
            // txtDuration
            // 
            this.txtDuration.AllowDrop = true;
            this.txtDuration.Location = new System.Drawing.Point(453, 316);
            this.txtDuration.Name = "txtDuration";
            this.txtDuration.Size = new System.Drawing.Size(177, 20);
            this.txtDuration.TabIndex = 9;
            // 
            // lstHostel
            // 
            this.lstHostel.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.hostelBindingSource, "Hostel Name", true));
            this.lstHostel.FormattingEnabled = true;
            this.lstHostel.Items.AddRange(new object[] {
            "E.G White",
            "NAGSDA",
            "Bediako",
            "J.J Nortey"});
            this.lstHostel.Location = new System.Drawing.Point(456, 102);
            this.lstHostel.MultiColumn = true;
            this.lstHostel.Name = "lstHostel";
            this.lstHostel.Size = new System.Drawing.Size(168, 56);
            this.lstHostel.TabIndex = 11;
            // 
            // hostelBindingSource
            // 
            this.hostelBindingSource.DataMember = "Hostel";
            this.hostelBindingSource.DataSource = this.hostelsDataSet;
            // 
            // hostelsDataSet
            // 
            this.hostelsDataSet.DataSetName = "HostelsDataSet";
            this.hostelsDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // lstRoom
            // 
            this.lstRoom.FormattingEnabled = true;
            this.lstRoom.HorizontalScrollbar = true;
            this.lstRoom.Items.AddRange(new object[] {
            "1 in a room",
            "2 in a room",
            "4 in a room"});
            this.lstRoom.Location = new System.Drawing.Point(459, 174);
            this.lstRoom.MultiColumn = true;
            this.lstRoom.Name = "lstRoom";
            this.lstRoom.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.lstRoom.Size = new System.Drawing.Size(165, 56);
            this.lstRoom.TabIndex = 12;
            // 
            // txtTotal
            // 
            this.txtTotal.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.txtTotal.Location = new System.Drawing.Point(453, 374);
            this.txtTotal.Name = "txtTotal";
            this.txtTotal.Size = new System.Drawing.Size(177, 23);
            this.txtTotal.TabIndex = 13;
            // 
            // btnCalculate
            // 
            this.btnCalculate.Location = new System.Drawing.Point(292, 431);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(83, 36);
            this.btnCalculate.TabIndex = 14;
            this.btnCalculate.Text = "Calculate";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // hostelTableAdapter
            // 
            this.hostelTableAdapter.ClearBeforeFill = true;
            // 
            // Reservation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 504);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.txtTotal);
            this.Controls.Add(this.lstRoom);
            this.Controls.Add(this.lstHostel);
            this.Controls.Add(this.txtDuration);
            this.Controls.Add(this.txtRoom);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Reservation";
            this.Text = "Reservation";
            this.Load += new System.EventHandler(this.Reservation_Load);
            ((System.ComponentModel.ISupportInitialize)(this.hostelBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hostelsDataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtRoom;
        private System.Windows.Forms.TextBox txtDuration;
        private System.Windows.Forms.ListBox lstHostel;
        private System.Windows.Forms.ListBox lstRoom;
        private System.Windows.Forms.Label txtTotal;
        private System.Windows.Forms.Button btnCalculate;
        private HostelsDataSet hostelsDataSet;
        private System.Windows.Forms.BindingSource hostelBindingSource;
        private HostelsDataSetTableAdapters.HostelTableAdapter hostelTableAdapter;
    }
}