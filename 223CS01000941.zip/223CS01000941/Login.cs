﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _223CS01000941
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnSignUp_Click(object sender, EventArgs e)
        {
            SignUp sign = new SignUp();
            sign.ShowDialog();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            String id = txtId.Text.ToString();
            String Password = txtPass.Text.ToString();

            SignUp sign = new SignUp();

            if (id == sign.getId(id) && Password == sign.getPassword(Password))
            {
                MessageBox.Show("Login Successfull");
                Reservation res = new Reservation();
                res.ShowDialog();
            }
            else
            {
                MessageBox.Show("Invalid Credentials");
            }



        }
    }
}
