using System.Diagnostics.Contracts;

namespace Calorie_Counter
{
    public partial class Form1 : Form
    {
        public int apple = 80;
        public int banana = 115;
        public int pear = 120;
        public int orange = 90;
        public int total = 0;
        public Form1()
        {
            InitializeComponent();

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            total += banana;
            showTotal.Text = total.ToString();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            total += apple;
            showTotal.Text = total.ToString();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            total += orange;
            showTotal.Text = total.ToString();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            total += pear;
            showTotal.Text = total.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            total = 0;
            showTotal.Text = "0";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
