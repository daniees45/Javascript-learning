namespace AbeebInterest
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            decimal p;
            decimal R;
            int T;
            const int div = 100;
            decimal I;

            //Data input
            p = Decimal.Parse(textPrincipal.Text);
            R = Decimal.Parse(textRate.Text);
            T = int.Parse(textTime.Text);

            I = (p * R * T) / div;

            //output
            textInterest.Text = I.ToString("C");

        }

        private void btnReset(object sender, EventArgs e)
        {
            textPrincipal.Text = "";
            textInterest.Text = "";
            textRate.Text = " ";
            textTime.Text = "";
        }

        private void btnExit(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
