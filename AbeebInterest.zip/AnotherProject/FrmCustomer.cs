﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AnotherProject
{
    public partial class frmCustomer : Form
    {
        public frmCustomer()
        {
            InitializeComponent();
        }
        public static string CustomerDetail = "";
        private void btnPaymentOption_Click(object sender, EventArgs e)
        {
            frmPayment myPayment = new frmPayment();
            CustomerDetail = GetFormDetails();
            myPayment.ShowDialog();
        }
        /
        private void cmbName_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void frmCustomer_Load(object sender, EventArgs e)
        {
            cmbName.Items.Add("Oladipupo Abeeb Olanrewaju");
            cmbName.Items.Add("Okoli Chidubem Paul");
            cmbName.Items.Add("Abel Nehemiah Adama");
            cmbName.Items.Add("Oladipupo Warris Bidemi");
            cmbName.Items.Add("Justine Pedasu Akossiwa");
            cmbName.Items.Add("Isaac Sabuki Akotey");

            cmbCountry.Items.Add("Nigeria");
            cmbCountry.Items.Add("Ghana");

            lstItem.Items.Add("Soap 25");
            lstItem.Items.Add("Milo 74");
            lstItem.Items.Add("Sugar 74");

        }

        public string GetFormDetails()
        {
            decimal price = 0;
            int qty = int.Parse(txtQuantity.Text);

            if (lstItem.SelectedIndex == 0)
            {
                price = qty * 25;
            }else if (lstItem.SelectedIndex == 1)
            {
                price = qty * 74;
            }
            else if (lstItem.SelectedIndex == 2)
            {
                price = qty * 74;
            }

            return "Customer Name:\t" + cmbName.SelectedItem.ToString() +"\n"+
                "Country :\t" + cmbCountry.SelectedItem.ToString() + "\n" +
                "Phone Number:\t" + txtPhoneNumber.Text.ToString() + "\n" +
                "Item Selected: \t" + lstItem.SelectedItem.ToString() + "\n" +
                "Quantity: \t" + txtQuantity.Text.ToString() + "\n" +
                "Amount:\t" + price.ToString() + "\n";
        }
    }
}
