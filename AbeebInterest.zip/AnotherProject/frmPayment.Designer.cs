﻿namespace AnotherProject
{
    partial class frmPayment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rdMtn = new System.Windows.Forms.RadioButton();
            this.rdAirteltigo = new System.Windows.Forms.RadioButton();
            this.rdVodafone = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lstCreditPayment = new System.Windows.Forms.ListBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cmbExpMonth = new System.Windows.Forms.ComboBox();
            this.cmbExpDate = new System.Windows.Forms.ComboBox();
            this.txtCVV = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtCardNumber = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.cmbBankName = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtAccountNumber = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.cmbBranch = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.mobilePaymenttToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mobilePaymenntToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.creditCardToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bankPaymentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.makePaymentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rdVodafone);
            this.groupBox1.Controls.Add(this.rdAirteltigo);
            this.groupBox1.Controls.Add(this.rdMtn);
            this.groupBox1.Location = new System.Drawing.Point(35, 40);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(171, 373);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Mobile Money Payment";
            // 
            // rdMtn
            // 
            this.rdMtn.AutoSize = true;
            this.rdMtn.Location = new System.Drawing.Point(39, 62);
            this.rdMtn.Name = "rdMtn";
            this.rdMtn.Size = new System.Drawing.Size(121, 17);
            this.rdMtn.TabIndex = 0;
            this.rdMtn.TabStop = true;
            this.rdMtn.Text = " MTN Mobile Money";
            this.rdMtn.UseVisualStyleBackColor = true;
            // 
            // rdAirteltigo
            // 
            this.rdAirteltigo.AutoSize = true;
            this.rdAirteltigo.Location = new System.Drawing.Point(39, 122);
            this.rdAirteltigo.Name = "rdAirteltigo";
            this.rdAirteltigo.Size = new System.Drawing.Size(89, 17);
            this.rdAirteltigo.TabIndex = 1;
            this.rdAirteltigo.TabStop = true;
            this.rdAirteltigo.Text = "Airteligo Cash";
            this.rdAirteltigo.UseVisualStyleBackColor = true;
            this.rdAirteltigo.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // rdVodafone
            // 
            this.rdVodafone.AutoSize = true;
            this.rdVodafone.Location = new System.Drawing.Point(39, 176);
            this.rdVodafone.Name = "rdVodafone";
            this.rdVodafone.Size = new System.Drawing.Size(98, 17);
            this.rdVodafone.TabIndex = 2;
            this.rdVodafone.TabStop = true;
            this.rdVodafone.Text = "Vodafone Cash";
            this.rdVodafone.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.groupBox3);
            this.groupBox2.Controls.Add(this.lstCreditPayment);
            this.groupBox2.Location = new System.Drawing.Point(244, 49);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(255, 364);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Credit Payment";
            // 
            // lstCreditPayment
            // 
            this.lstCreditPayment.FormattingEnabled = true;
            this.lstCreditPayment.Items.AddRange(new object[] {
            "VISA",
            "MasterCard",
            "Ezwich",
            "PayPal",
            "Union Pay"});
            this.lstCreditPayment.Location = new System.Drawing.Point(15, 38);
            this.lstCreditPayment.Name = "lstCreditPayment";
            this.lstCreditPayment.Size = new System.Drawing.Size(234, 108);
            this.lstCreditPayment.TabIndex = 0;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.txtCardNumber);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.txtCVV);
            this.groupBox3.Controls.Add(this.cmbExpDate);
            this.groupBox3.Controls.Add(this.cmbExpMonth);
            this.groupBox3.Location = new System.Drawing.Point(6, 167);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(249, 191);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Card Detail";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Card Type";
            // 
            // cmbExpMonth
            // 
            this.cmbExpMonth.FormattingEnabled = true;
            this.cmbExpMonth.Location = new System.Drawing.Point(105, 62);
            this.cmbExpMonth.Name = "cmbExpMonth";
            this.cmbExpMonth.Size = new System.Drawing.Size(138, 21);
            this.cmbExpMonth.TabIndex = 0;
            // 
            // cmbExpDate
            // 
            this.cmbExpDate.FormattingEnabled = true;
            this.cmbExpDate.Location = new System.Drawing.Point(105, 103);
            this.cmbExpDate.Name = "cmbExpDate";
            this.cmbExpDate.Size = new System.Drawing.Size(138, 21);
            this.cmbExpDate.TabIndex = 1;
            // 
            // txtCVV
            // 
            this.txtCVV.Location = new System.Drawing.Point(105, 148);
            this.txtCVV.Name = "txtCVV";
            this.txtCVV.Size = new System.Drawing.Size(138, 20);
            this.txtCVV.TabIndex = 2;
            this.txtCVV.UseSystemPasswordChar = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(0, 63);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Expiration Month";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(0, 104);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Expiration Date";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(9, 148);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(28, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "CVV";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(9, 25);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(69, 13);
            this.label5.TabIndex = 6;
            this.label5.Text = "Card Number";
            // 
            // txtCardNumber
            // 
            this.txtCardNumber.Location = new System.Drawing.Point(105, 25);
            this.txtCardNumber.Name = "txtCardNumber";
            this.txtCardNumber.Size = new System.Drawing.Size(138, 20);
            this.txtCardNumber.TabIndex = 7;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label8);
            this.groupBox4.Controls.Add(this.cmbBranch);
            this.groupBox4.Controls.Add(this.label7);
            this.groupBox4.Controls.Add(this.txtAccountNumber);
            this.groupBox4.Controls.Add(this.label6);
            this.groupBox4.Controls.Add(this.cmbBankName);
            this.groupBox4.Location = new System.Drawing.Point(519, 49);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(220, 364);
            this.groupBox4.TabIndex = 2;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Bank Payment";
            // 
            // cmbBankName
            // 
            this.cmbBankName.FormattingEnabled = true;
            this.cmbBankName.Location = new System.Drawing.Point(20, 62);
            this.cmbBankName.Name = "cmbBankName";
            this.cmbBankName.Size = new System.Drawing.Size(178, 21);
            this.cmbBankName.TabIndex = 0;
            this.cmbBankName.SelectedIndexChanged += new System.EventHandler(this.comboBox3_SelectedIndexChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(20, 38);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(63, 13);
            this.label6.TabIndex = 1;
            this.label6.Text = "Bank Name";
            // 
            // txtAccountNumber
            // 
            this.txtAccountNumber.Location = new System.Drawing.Point(20, 164);
            this.txtAccountNumber.Name = "txtAccountNumber";
            this.txtAccountNumber.Size = new System.Drawing.Size(178, 20);
            this.txtAccountNumber.TabIndex = 2;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(20, 132);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(87, 13);
            this.label7.TabIndex = 3;
            this.label7.Text = "Account Number";
            // 
            // cmbBranch
            // 
            this.cmbBranch.FormattingEnabled = true;
            this.cmbBranch.Location = new System.Drawing.Point(20, 249);
            this.cmbBranch.Name = "cmbBranch";
            this.cmbBranch.Size = new System.Drawing.Size(178, 21);
            this.cmbBranch.TabIndex = 4;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(23, 209);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(41, 13);
            this.label8.TabIndex = 5;
            this.label8.Text = "Branch";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mobilePaymenttToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(789, 24);
            this.menuStrip1.TabIndex = 3;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // mobilePaymenttToolStripMenuItem
            // 
            this.mobilePaymenttToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mobilePaymenntToolStripMenuItem,
            this.creditCardToolStripMenuItem,
            this.bankPaymentToolStripMenuItem,
            this.makePaymentToolStripMenuItem});
            this.mobilePaymenttToolStripMenuItem.Name = "mobilePaymenttToolStripMenuItem";
            this.mobilePaymenttToolStripMenuItem.Size = new System.Drawing.Size(111, 20);
            this.mobilePaymenttToolStripMenuItem.Text = "Payment Options";
            this.mobilePaymenttToolStripMenuItem.Click += new System.EventHandler(this.mobilePaymenttToolStripMenuItem_Click);
            // 
            // mobilePaymenntToolStripMenuItem
            // 
            this.mobilePaymenntToolStripMenuItem.Name = "mobilePaymenntToolStripMenuItem";
            this.mobilePaymenntToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.mobilePaymenntToolStripMenuItem.Text = "Mobile Payment";
            // 
            // creditCardToolStripMenuItem
            // 
            this.creditCardToolStripMenuItem.Name = "creditCardToolStripMenuItem";
            this.creditCardToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.creditCardToolStripMenuItem.Text = "Credit Card";
            this.creditCardToolStripMenuItem.Click += new System.EventHandler(this.creditCardToolStripMenuItem_Click);
            // 
            // bankPaymentToolStripMenuItem
            // 
            this.bankPaymentToolStripMenuItem.Name = "bankPaymentToolStripMenuItem";
            this.bankPaymentToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.bankPaymentToolStripMenuItem.Text = "Bank Payment";
            // 
            // makePaymentToolStripMenuItem
            // 
            this.makePaymentToolStripMenuItem.Name = "makePaymentToolStripMenuItem";
            this.makePaymentToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.makePaymentToolStripMenuItem.Text = "Make Payment";
            // 
            // frmPayment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(789, 529);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmPayment";
            this.Text = "Payment Details";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rdVodafone;
        private System.Windows.Forms.RadioButton rdAirteltigo;
        private System.Windows.Forms.RadioButton rdMtn;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ListBox lstCreditPayment;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox txtCardNumber;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtCVV;
        private System.Windows.Forms.ComboBox cmbExpDate;
        private System.Windows.Forms.ComboBox cmbExpMonth;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.ComboBox cmbBankName;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cmbBranch;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtAccountNumber;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem mobilePaymenttToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mobilePaymenntToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem creditCardToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bankPaymentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem makePaymentToolStripMenuItem;
    }
}