using System;

namespace Calculator
{
    
    public partial class Form1 : Form
    {
        public double value1;
        public double value2;
        public double output;
        public string input;
        
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void txtbox_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            txtbox.AppendText("1");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            txtbox.AppendText("2");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            txtbox.AppendText("5");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            txtbox.AppendText("6");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            txtbox.AppendText("3");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            txtbox.AppendText("4");
        }

        private void button7_Click(object sender, EventArgs e)
        {
            txtbox.AppendText("7");
        }

        private void button8_Click(object sender, EventArgs e)
        {
            txtbox.AppendText("8");
        }

        private void button9_Click(object sender, EventArgs e)
        {
            txtbox.AppendText("9");
        }

        private void button10_Click(object sender, EventArgs e)
        {
            txtbox.AppendText("0");
        }

        private void button11_Click(object sender, EventArgs e)

        {
            txtbox.AppendText("+");
        }

        private void button13_Click(object sender, EventArgs e)
        {
            txtbox.AppendText("-");
        }

        private void button12_Click(object sender, EventArgs e)
        {
            txtbox.AppendText("*");
        }

        private void button14_Click(object sender, EventArgs e)
        {
            txtbox.AppendText("/");
        }

        private void button15_Click(object sender, EventArgs e)
        {

            if (txtbox.Text.Contains('+'))
            {
                char ch = txtbox.Text[0];
                if (ch == '+')
                {
                    string l = txtbox.Text.Remove(0, 1);

                    if (l.Contains('+'))
                    {
                        string[] s = l.Split('+');
                        for (int i = 0; i < s.Length; i++)
                        {
                            output += double.Parse(s[i]);
                        }
                    }else if (l.Contains('-'))
                    {
                        string[] s = l.Split('-');
                        for (int i = 0; i < s.Length; i++)
                        {
                            output =- double.Parse(s[i]);
                        }
                    }

                }
                else if (ch == '-')
                {
                    string l = txtbox.Text.Remove(0, 1);
                    string[] s = l.Split('-');
                    for (int i = 0; i < s.Length; i++)
                    {
                        output -= double.Parse(s[i]);
                    }

                }
            }



            txtbox.Text = output.ToString();
            output = 0;
        }
    }
}
