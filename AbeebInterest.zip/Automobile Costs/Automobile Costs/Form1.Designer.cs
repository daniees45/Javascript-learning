﻿namespace Automobile_Costs
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            txtLoan = new TextBox();
            txtInsure = new TextBox();
            txtGas = new TextBox();
            txtOil = new TextBox();
            txtTires = new TextBox();
            txtMain = new TextBox();
            label7 = new Label();
            txtCost = new TextBox();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            label8 = new Label();
            annual = new TextBox();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(58, 51);
            label1.Name = "label1";
            label1.Size = new Size(139, 25);
            label1.TabIndex = 0;
            label1.Text = "Loan Payment";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(58, 107);
            label2.Name = "label2";
            label2.Size = new Size(99, 25);
            label2.TabIndex = 1;
            label2.Text = "Insurance";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(58, 164);
            label3.Name = "label3";
            label3.Size = new Size(44, 25);
            label3.TabIndex = 2;
            label3.Text = "Gas";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(58, 214);
            label4.Name = "label4";
            label4.Size = new Size(36, 25);
            label4.TabIndex = 3;
            label4.Text = "Oil";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(58, 270);
            label5.Name = "label5";
            label5.Size = new Size(54, 25);
            label5.TabIndex = 4;
            label5.Text = "Tires";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.Location = new Point(58, 327);
            label6.Name = "label6";
            label6.Size = new Size(127, 25);
            label6.TabIndex = 5;
            label6.Text = "Maintenance";
            // 
            // txtLoan
            // 
            txtLoan.Location = new Point(259, 53);
            txtLoan.Name = "txtLoan";
            txtLoan.Size = new Size(246, 23);
            txtLoan.TabIndex = 6;
            txtLoan.Text = "0";
            // 
            // txtInsure
            // 
            txtInsure.Location = new Point(259, 112);
            txtInsure.Name = "txtInsure";
            txtInsure.Size = new Size(246, 23);
            txtInsure.TabIndex = 7;
            txtInsure.Text = "0";
            // 
            // txtGas
            // 
            txtGas.Location = new Point(259, 166);
            txtGas.Name = "txtGas";
            txtGas.Size = new Size(246, 23);
            txtGas.TabIndex = 8;
            txtGas.Text = "0";
            // 
            // txtOil
            // 
            txtOil.Location = new Point(259, 219);
            txtOil.Name = "txtOil";
            txtOil.Size = new Size(246, 23);
            txtOil.TabIndex = 9;
            txtOil.Text = "0";
            // 
            // txtTires
            // 
            txtTires.Location = new Point(259, 275);
            txtTires.Name = "txtTires";
            txtTires.Size = new Size(246, 23);
            txtTires.TabIndex = 10;
            txtTires.Text = "0";
            // 
            // txtMain
            // 
            txtMain.Location = new Point(259, 327);
            txtMain.Name = "txtMain";
            txtMain.Size = new Size(246, 23);
            txtMain.TabIndex = 11;
            txtMain.Text = "0";
            txtMain.TextChanged += textBox6_TextChanged;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.Location = new Point(58, 392);
            label7.Name = "label7";
            label7.Size = new Size(179, 25);
            label7.TabIndex = 12;
            label7.Text = "Total Monthly Cost";
            // 
            // txtCost
            // 
            txtCost.Location = new Point(259, 392);
            txtCost.Name = "txtCost";
            txtCost.ReadOnly = true;
            txtCost.Size = new Size(246, 23);
            txtCost.TabIndex = 13;
            // 
            // button1
            // 
            button1.BackColor = Color.Lime;
            button1.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.Location = new Point(259, 511);
            button1.Name = "button1";
            button1.Size = new Size(113, 42);
            button1.TabIndex = 14;
            button1.Text = "Calculate";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.Yellow;
            button2.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.Location = new Point(392, 511);
            button2.Name = "button2";
            button2.Size = new Size(113, 42);
            button2.TabIndex = 15;
            button2.Text = "Reset";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.BackColor = Color.Red;
            button3.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button3.Location = new Point(529, 511);
            button3.Name = "button3";
            button3.Size = new Size(113, 42);
            button3.TabIndex = 16;
            button3.Text = "Exit";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.Location = new Point(58, 447);
            label8.Name = "label8";
            label8.Size = new Size(120, 25);
            label8.TabIndex = 17;
            label8.Text = "Annual Cost";
            // 
            // annual
            // 
            annual.Location = new Point(259, 447);
            annual.Name = "annual";
            annual.ReadOnly = true;
            annual.Size = new Size(246, 23);
            annual.TabIndex = 18;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(817, 588);
            Controls.Add(annual);
            Controls.Add(label8);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(txtCost);
            Controls.Add(label7);
            Controls.Add(txtMain);
            Controls.Add(txtTires);
            Controls.Add(txtOil);
            Controls.Add(txtGas);
            Controls.Add(txtInsure);
            Controls.Add(txtLoan);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private TextBox txtLoan;
        private TextBox txtInsure;
        private TextBox txtGas;
        private TextBox txtOil;
        private TextBox txtTires;
        private TextBox txtMain;
        private Label label7;
        private TextBox txtCost;
        private Button button1;
        private Button button2;
        private Button button3;
        private Label label8;
        private TextBox annual;
    }
}
