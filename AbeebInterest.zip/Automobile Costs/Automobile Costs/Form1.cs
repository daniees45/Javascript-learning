namespace Automobile_Costs
{
    using System;
    using System.Globalization;
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            double loan;
            double insure;
            double gas;
            double oil;
            double tires;
            double main;
            double cost;
            double year;

            loan = double.Parse(txtLoan.Text);
            insure = double.Parse(txtInsure.Text);
            gas = double.Parse(txtGas.Text);
            oil = double.Parse(txtOil.Text);
            tires = double.Parse(txtTires.Text);
            main = double.Parse(txtMain.Text);

            cost = loan + insure + gas + oil + tires + main;
            year = cost * 12;

            txtCost.Text = cost.ToString("C", CultureInfo.GetCultureInfo("en-GH"));
            annual.Text = year.ToString("C", CultureInfo.GetCultureInfo("en-GH"));

        }

        private void button2_Click(object sender, EventArgs e)
        {
            txtCost.Text = "0";
            txtInsure.Text = "0";
            txtGas.Text = "0";
            txtMain.Text = "0";
            txtLoan.Text = "0";
            txtTires.Text = "0";
            txtOil.Text = "0";
            annual.Text = "0";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
