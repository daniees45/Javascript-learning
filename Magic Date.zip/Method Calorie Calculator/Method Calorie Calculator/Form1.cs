namespace Method_Calorie_Calculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //Method to Calculate Calories for Fat
        private int FatCalories(int fatGrams)
        {

            return fatGrams * 9;
        }

        private int FatCarbo(int CarboGrams)
        {
            return CarboGrams * 4;
        }
        private void btnCalculate_Click(object sender, EventArgs e)
        {
            int fatGrams, CarboGrams;
            //validate input
            if (int.TryParse(txtFat.Text, out fatGrams) && fatGrams >= 0 && int.TryParse(txtCarbo.Text, out CarboGrams) && CarboGrams >= 0)
            {
                // perform calculations
                int fatCalories = FatCalories(fatGrams);
                int carbCalories = FatCarbo(CarboGrams);

                //Display result
                lblFat.Text = $"Calories from Fat Intake: {fatCalories}";
                lblCarbo.Text = $"Calories from Carbohydrate intake: {carbCalories}";
            }
            else
            {
                MessageBox.Show("Please enter a valid input for fat and calories");
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtCarbo.Text = " ";
            txtFat.Text = " ";
            lblCarbo.Text = " ";
            lblFat.Text = " ";
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}

['']