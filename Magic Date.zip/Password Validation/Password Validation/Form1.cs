using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Password_Validation
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private int NumberUpperCase(string str)
        {
            int UpperCASE = 0;

            foreach (char ch in str)
            {
                if (char.IsUpper(ch))
                {
                    UpperCASE++;
                }
            }
            return UpperCASE;
        }

        private int NumberLowerCase(string str)
        {
            int LowerCASE = 0;
            foreach (char ch in str)
            {
                if (char.IsLower(ch))
                {
                    LowerCASE++;
                }
            }
            return LowerCASE;
        }

        private int NumberDigit(string str)
        {
            int Digit = 0;

            foreach (char ch in str)
            {
                if (char.IsDigit(ch))
                {
                    Digit++;
                }
            }
            return Digit;
        }
        private void btnCheck_Click(object sender, EventArgs e)
        {
            const int Min_Length = 8;
            string password = txtPassword.Text;

            if (password.Length >= Min_Length && NumberUpperCase(password) >= 1 && NumberLowerCase(password) >= 1 && NumberDigit(password) >= 1)
            {
                MessageBox.Show("The Password is valid", "Validity");
            }
            else
            {
               MessageBox.Show("The Password does not meet the requirements.", "Invalid");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
