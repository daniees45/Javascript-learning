namespace Text_Processing
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnProcess_Click(object sender, EventArgs e)
        {
            String input = txtInput.Text;
            if (String.IsNullOrEmpty(input))
            {
                lblResults.Text = "Input cannot be empty";
                return;
            }
            // convert to lowercase for case insensitity and remove spaces
            input = new String(input.ToLower().Where(c => !char.IsWhiteSpace(c)).ToArray());
            var mostFrequent = input.GroupBy(c => c)
                //Group characters
            .OrderByDescending(g =>g.Count())
            .FirstOrDefault(); // This is to get the most frequent character

            if (mostFrequent != null)
            {
                lblResults.Text = $"Most Frequent character: '{mostFrequent.Key}' appears {mostFrequent.Count()} times";
            }
            {
                
            }

        }
    }
}
