namespace Magic_Date
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int Day;
            int Month;
            int Year;
            int.TryParse(txtDay.Text, out Day);
            int.TryParse(txtMonth.Text, out Month);
            int.TryParse(txtYear.Text, out Year);

            if (txtYear.Text.Length == 2)
            {
                if (Day > 0 && Day <= 31 && Month > 0 && Month <= 12)
                {
                    int answer = Day * Month;
                    if (answer == Year)
                    {
                        MessageBox.Show("The Date is Magic", "Magic Date");

                    }
                    else
                    {
                        MessageBox.Show("The Date is not Magic", "Magic Date");
                    }
                }
                else
                {
                    MessageBox.Show("The Day and Month must not be less than 1 or  greater than 12 or 31", "ERROR");
                }
            }
            else
            {
                MessageBox.Show("The Year must be 2-digit. e.g. 24, 25 ", "ERROR");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            txtYear.Text = " ";
            txtMonth.Text = " ";
            txtDay.Text = "";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
