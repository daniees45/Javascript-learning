using System.Globalization;

namespace VVU_Fees_Calculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public double genCharge = 1800;
        public double labFee = 150;
        public double clinicals = 560;
        public double creditRate = 120;
        public double fees;


        private void btnCalculate_Click(object sender, EventArgs e)
        {
            double credits;
            double.TryParse(txtHours.Text, out credits);
            double schoolRate = 15.8;

            if (credits > 0 && credits <= 24)
            {
                if ((radioRegular.Checked || radioDistance.Checked || radioSandwich.Checked) && (radioLocal.Checked || radioForeign.Checked) && (radioNormal.Checked || radioProject.Checked))
                {

                    if (listDepartment.Text.Equals("Computer Science"))
                    {
                        if (radioForeign.Checked)
                        {
                            fees = (genCharge + labFee + (creditRate * credits)) / schoolRate;
                        }
                        else
                        {
                            fees = genCharge + labFee + (creditRate * credits);
                        }

                    }
                    else if (listDepartment.Text.Equals("Education"))
                    {
                        if (radioForeign.Checked)
                        {
                            fees = (genCharge + (creditRate * credits)) / schoolRate;
                        }
                        else
                        {
                            fees = genCharge + (creditRate * credits);
                        }

                    }
                    else if (listDepartment.Text.Equals("Theology"))
                    {
                        if (radioForeign.Checked)
                        {
                            fees = (genCharge + (creditRate * credits) - (creditRate * credits * 0.3)) / schoolRate;
                        }
                        else
                        {
                            fees = genCharge + (creditRate * credits) - (creditRate * credits * 0.3);
                        }

                    }
                    else if (listDepartment.Text.Equals("Business Administration"))
                    {
                        if (radioForeign.Checked)
                        {
                            fees = (genCharge + (creditRate * credits)) / schoolRate;
                        }
                        else
                        {
                            fees = genCharge + (creditRate * credits);
                        }

                    }
                    else if (listDepartment.Text.Equals("Nursing & Midwifery"))
                    {
                        if (radioForeign.Checked)
                        {
                            fees = (genCharge + labFee + clinicals + (creditRate * credits)) / schoolRate;
                        }
                        else
                        {
                            fees = genCharge + labFee + clinicals + (creditRate * credits);
                        }

                    }
                    else if (listDepartment.Text.Equals("Development Studies"))
                    {
                        if (radioForeign.Checked)
                        {
                            fees = (genCharge + (creditRate * credits)) / schoolRate;
                        }
                        else
                        {
                            fees = genCharge + (creditRate * credits);
                        }

                    }

                    if (radioForeign.Checked)
                    {
                        txtfees.Text = fees.ToString("C");
                    }
                    else
                    {
                        txtfees.Text = fees.ToString("C", CultureInfo.GetCultureInfo("en-GH"));
                    }
                }
                else
                {
                    MessageBox.Show("Check all required data", "Required data");
                }

            }
            else
            {
                MessageBox.Show("Input number of credits between 1 and 24", "The credit Hours is Invalid");
            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            txtHours.Text = "";
            radioLocal.Checked = false;
            radioDistance.Checked = false;
            radioForeign.Checked = false;
            radioNormal.Checked = false;
            radioProject.Checked = false;
            radioRegular.Checked = false;
            radioSandwich.Checked = false;
            txtfees.Text = "0.00";


        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
