using System;
using System.Windows.Forms;

namespace Tic_Tac_Toe
{
    public partial class Form1 : Form
    {
        private RichTextBox[,] txt = new RichTextBox[3, 3];
        private int[,] Board = new int[3, 3];
        private bool GameOver = false;
        private string winner = "";
        private Random random = new Random();

        public Form1()
        {
            InitializeComponent();
            InitializeTextBoxes();
        }

        // *Link textboxes to 2D array*
        private void InitializeTextBoxes()
        {
            txt[0, 0] = txt00; txt[0, 1] = txt01; txt[0, 2] = txt02;
            txt[1, 0] = txt10; txt[1, 1] = txt11; txt[1, 2] = txt12;
            txt[2, 0] = txt20; txt[2, 1] = txt21; txt[2, 2] = txt22;
        }

        // *New Game Button Click*
        private void btnGame_Click(object sender, EventArgs e)
        {
            if (GameOver) // Reset if game was over
            {
                GameOver = false;
                winner = "";
            }

            // Randomly assign X and O (1 and 0)
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Board[i, j] = random.Next(2);
                    txt[i, j].Text = (Board[i, j] == 1) ? "X" : "O";
                }
            }

            // *Check for a winner*
            CheckWinner();
            if (GameOver)
            {
                lblWins.Text = winner;
            }
        }

        // *Check if there is a winner*
        private void CheckWinner()
        {
            for (int i = 0; i < 3; i++)
            {
                if (Board[i, 0] == Board[i, 1] && Board[i, 1] == Board[i, 2])
                {
                    SetWinner(Board[i, 0]);
                    return;
                }

                if (Board[0, i] == Board[1, i] && Board[1, i] == Board[2, i])
                {
                    SetWinner(Board[0, i]);
                    return;
                }
            }

            if (Board[0, 0] == Board[1, 1] && Board[1, 1] == Board[2, 2])
            {
                SetWinner(Board[0, 0]);
                return;
            }

            if (Board[0, 2] == Board[1, 1] && Board[1, 1] == Board[2, 0])
            {
                SetWinner(Board[0, 2]);
                return;
            }

            lblWins.Text = "It's a tie!";
        }

        // *Set winner message*
        private void SetWinner(int player)
        {
            GameOver = true;
            winner = (player == 1) ? "X Wins!" : "O Wins!";
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {

                    txt[i, j].Text = "";
                }
            }
            lblWins.Text = "";
        }
    }
}