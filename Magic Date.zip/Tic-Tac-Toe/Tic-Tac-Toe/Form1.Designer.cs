﻿namespace Tic_Tac_Toe
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txt00 = new RichTextBox();
            txt01 = new RichTextBox();
            txt02 = new RichTextBox();
            txt10 = new RichTextBox();
            txt11 = new RichTextBox();
            txt12 = new RichTextBox();
            txt20 = new RichTextBox();
            txt21 = new RichTextBox();
            txt22 = new RichTextBox();
            lblWins = new Label();
            btnGame = new Button();
            btnExit = new Button();
            btnClear = new Button();
            SuspendLayout();
            // 
            // txt00
            // 
            txt00.Location = new Point(88, 35);
            txt00.Name = "txt00";
            txt00.ReadOnly = true;
            txt00.Size = new Size(62, 58);
            txt00.TabIndex = 0;
            txt00.Text = "";
            // 
            // txt01
            // 
            txt01.Location = new Point(195, 35);
            txt01.Name = "txt01";
            txt01.ReadOnly = true;
            txt01.Size = new Size(62, 58);
            txt01.TabIndex = 1;
            txt01.Text = "";
            // 
            // txt02
            // 
            txt02.Location = new Point(306, 35);
            txt02.Name = "txt02";
            txt02.ReadOnly = true;
            txt02.Size = new Size(62, 58);
            txt02.TabIndex = 2;
            txt02.Text = "";
            // 
            // txt10
            // 
            txt10.Location = new Point(88, 118);
            txt10.Name = "txt10";
            txt10.ReadOnly = true;
            txt10.Size = new Size(62, 58);
            txt10.TabIndex = 3;
            txt10.Text = "";
            // 
            // txt11
            // 
            txt11.Location = new Point(204, 118);
            txt11.Name = "txt11";
            txt11.ReadOnly = true;
            txt11.Size = new Size(62, 58);
            txt11.TabIndex = 4;
            txt11.Text = "";
            // 
            // txt12
            // 
            txt12.Location = new Point(306, 118);
            txt12.Name = "txt12";
            txt12.ReadOnly = true;
            txt12.Size = new Size(62, 58);
            txt12.TabIndex = 5;
            txt12.Text = "";
            // 
            // txt20
            // 
            txt20.Location = new Point(88, 196);
            txt20.Name = "txt20";
            txt20.ReadOnly = true;
            txt20.Size = new Size(62, 58);
            txt20.TabIndex = 6;
            txt20.Text = "";
            // 
            // txt21
            // 
            txt21.Location = new Point(204, 196);
            txt21.Name = "txt21";
            txt21.ReadOnly = true;
            txt21.Size = new Size(62, 58);
            txt21.TabIndex = 7;
            txt21.Text = "";
            // 
            // txt22
            // 
            txt22.Location = new Point(306, 196);
            txt22.Name = "txt22";
            txt22.ReadOnly = true;
            txt22.Size = new Size(62, 58);
            txt22.TabIndex = 8;
            txt22.Text = "";
            // 
            // lblWins
            // 
            lblWins.Location = new Point(88, 267);
            lblWins.Name = "lblWins";
            lblWins.Size = new Size(280, 41);
            lblWins.TabIndex = 9;
            lblWins.Text = " ";
            // 
            // btnGame
            // 
            btnGame.Location = new Point(88, 311);
            btnGame.Name = "btnGame";
            btnGame.Size = new Size(106, 35);
            btnGame.TabIndex = 10;
            btnGame.Text = "New Game";
            btnGame.UseVisualStyleBackColor = true;
            btnGame.Click += btnGame_Click;
            // 
            // btnExit
            // 
            btnExit.Location = new Point(297, 311);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(106, 35);
            btnExit.TabIndex = 11;
            btnExit.Text = "Exit";
            btnExit.UseVisualStyleBackColor = true;
            btnExit.Click += btnExit_Click;
            // 
            // btnClear
            // 
            btnClear.Location = new Point(204, 311);
            btnClear.Name = "btnClear";
            btnClear.Size = new Size(87, 35);
            btnClear.TabIndex = 12;
            btnClear.Text = "Clear";
            btnClear.UseVisualStyleBackColor = true;
            btnClear.Click += btnClear_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(495, 401);
            Controls.Add(btnClear);
            Controls.Add(btnExit);
            Controls.Add(btnGame);
            Controls.Add(lblWins);
            Controls.Add(txt22);
            Controls.Add(txt21);
            Controls.Add(txt20);
            Controls.Add(txt12);
            Controls.Add(txt11);
            Controls.Add(txt10);
            Controls.Add(txt02);
            Controls.Add(txt01);
            Controls.Add(txt00);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
        }

        #endregion

        private RichTextBox txt00;
        private RichTextBox txt01;
        private RichTextBox txt02;
        private RichTextBox txt10;
        private RichTextBox txt11;
        private RichTextBox txt12;
        private RichTextBox txt20;
        private RichTextBox txt21;
        private RichTextBox txt22;
        private Label lblWins;
        private Button btnGame;
        private Button btnExit;
        private Button btnClear;
    }
}
