﻿using System;

public class TicTacToe

{
	public int[,] Board { get; private set; } = new int[3, 3];
	public bool GameOver { get; private set; } = false;
	public string winner { get; private set; } = "";
	private Random random = new Random();
	public void InitializeBoard()
	{
		for (int i = 0; i < 3; i++)
		{
			for(int j = 0; j < 3; j++)
			{
				Board[i, j] = random.Next(2);
			}
		}
	}
	public void CheckWinner()
	{
		for(int i = 0;i < 3; i++)
		{
            if (Board[i, 0] == Board[i,1] && Board[i,1] == Board[i,2])
            {
				SetWinner(Board[i, 0]);
				return;
            }

			if(Board[0, i] == Board[1, i] && Board[1, i] == Board[2, i])
			{
				SetWinner(Board[0, i]);
				return;
			}
        }

        if (Board[0,0] == Board[1,1] && Board[1,1] == Board[2, 2])
        {
			SetWinner(Board[0, 0]);
			return;
        }

        if (Board[0, 2] == Board[1, 1] && Board[1, 1] == Board[2, 0])
        {
			SetWinner(Board[0, 2]);
			return;
        }

		Winner = "It's a tie";

    }

	private void SetWinner(int player)
	{
		GameOver = true;
		winner = (player == 1) ? "X Wins!" : "0 Wins!";
	}
}
